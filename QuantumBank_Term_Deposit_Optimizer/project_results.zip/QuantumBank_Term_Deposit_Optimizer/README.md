# QuantumBank – Intelligent Term Deposit Campaign Optimizer
## Hybrid Quantum-Classical Machine Learning & Optimization Pipeline

[![Python 3.13](https://img.shields.io/badge/Python-3.13-blue.svg)](https://www.python.org/)
[![Qiskit 2.6](https://img.shields.io/badge/Qiskit-2.6.2-blueviolet.svg)](https://qiskit.org/)
[![Qiskit Aer](https://img.shields.io/badge/Qiskit--Aer-0.18.2-purple.svg)](https://github.com/Qiskit/qiskit-aer)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

An intelligent banking campaign system designed for the **TheAtomIQ Hackathon**. It predicts customer term-deposit subscription probabilities, solves a constrained combinatorial customer contact portfolio using the **Quantum Approximate Optimization Algorithm (QAOA)**, and simulates campaign conversion outcomes on a 6-qubit quantum state preparation circuit.

---

## 🚀 Quick Start Guide

### 1. Installation
Clone the repository and install all required dependencies:
```bash
git clone https://github.com/space-swap01/TheAtomIQ-Hackathon.git
cd QuantumBank_Term_Deposit_Optimizer
pip install -r requirements.txt
```

### 2. Execute the Full Pipeline (Single Command)
Run the automated end-to-end pipeline in under 15 seconds:
```bash
python run_pipeline.py
```
This executes:
- Data validation and strictly train-fitted preprocessing (no leakage).
- 5-fold Stratified Cross-Validation on 5 classical models + 1 QML Quantum Kernel Classifier.
- Stage 1 test predictions and candidate ranking -> `outputs/stage1_predictions.csv`.
- Stage 2 QAOA optimization and classical brute force -> `outputs/stage2_optimization_results.csv`.
- Stage 3 6-qubit quantum simulation -> `outputs/stage3_quantum_simulation_results.csv`.
- Publication-quality chart generation (18 charts) -> `outputs/charts/`.
- Executive Summary PDF -> `reports/executive_summary.pdf`.

### 3. Launch the Streamlit Interactive Dashboard
```bash
streamlit run app.py
```
Opens the modern fintech analytics dashboard at `http://localhost:8501`.

---

## 🏛️ System Architecture & Workflow

```
   ┌────────────────────────────────────────────────────────┐
   │             Stage 1: Predict & Rank                    │
   │  • 300 Train (1:7.6 Imbalance) -> 5-Fold Stratified CV │
   │  • Models: LogisticReg, RF, XGBoost, SVM, GBDT, QML   │
   │  • Champion Model: Gradient Boosting (PR-AUC: 0.2490)  │
   │  • Predict 100 Test Customers -> Extract Top 10        │
   └───────────────────────────┬────────────────────────────┘
                               │ (Top 10 Candidates & Continuous Probabilities)
                               ▼
   ┌────────────────────────────────────────────────────────┐
   │          Stage 2: Constrained Optimization             │
   │  • Maximize Expected Net Value = p_i * V_i - c_i       │
   │  • Hard Constraints: K=6, Budget<=25€, Capacity<=22U   │
   │  • QAOA Solver (10 Qubits, AerSimulator, Nelder-Mead)  │
   │  • Classical Brute Force Benchmark (210 combinations)  │
   │  • Final Selection: 6 Feasible Customers (56.33€ Net)  │
   └───────────────────────────┬────────────────────────────┘
                               │ (Selected 6 Customers & Original Probabilities)
                               ▼
   ┌────────────────────────────────────────────────────────┐
   │          Stage 3: Quantum Outcome Simulation           │
   │  • 6-Qubit Circuit: RY(theta_i)|0> State Preparation   │
   │  • theta_i = 2 * arcsin(sqrt(p_i)) => P(|1>) = p_i     │
   │  • AerSimulator Sampling (200,000 shots)               │
   │  • Target: P(Subscribers >= 3)                         │
   │  • Quantum: 73.32% | Exact Analytical: 73.26%          │
   └────────────────────────────────────────────────────────┘
```

---

## 📊 Summary of Key Results

| Stage / Component | Key Metric | Result / Status |
| :--- | :--- | :--- |
| **Stage 1 Champion Model** | Gradient Boosting | ROC-AUC: **0.6635** \| PR-AUC: **0.2490** \| Brier: **0.1046** |
| **Stage 1 Quantum Model** | QSVC (ZZFeatureMap, 4Q) | Brier: **0.1022** (Lowest) \| ECE: **0.0016** (Best) |
| **Stage 1 Top Candidate** | Customer `C0081` | Predicted Probability: **0.877566** (Rank 1) |
| **Stage 2 QAOA Objective** | Expected Net Value | **56.3320 EUR** (Classical: 63.4186 EUR) |
| **Stage 2 Budget & Capacity** | Contact Cost & Capacity | **11.0 / 25.0 EUR** (Feasible) \| **16.0 / 22.0 Units** (Feasible) |
| **Stage 2 Selected Cohort** | 6 Customers | `C0079`, `C0031`, `C0327`, `C0059`, `C0256`, `C0170` |
| **Stage 3 Quantum Aer P(K>=3)** | 200,000 Shots | **73.320%** |
| **Stage 3 Exact Poisson-Binomial** | Dynamic Programming | **73.262%** |
| **Stage 3 Monte Carlo P(K>=3)** | 200,000 Trials | **73.267%** (Absolute Error: **0.000054**) |
| **Quantum vs Exact Error** | $\|P_{\text{quantum}} - P_{\text{exact}}\|$ | **0.000584** (Sub-0.0006 error) |

---

## 📁 Repository Structure

```
QuantumBank_Term_Deposit_Optimizer/
│
├── data/
│   ├── bank_campaign_participant_release.xlsx  # Official hackathon dataset
│   └── PROBLEM_STATEMENT_THEATOMIQHACKTHON.pdf # Official challenge rules
│
├── notebooks/                                  # 5 Step-by-Step Jupyter Notebooks
│   ├── 01_data_exploration.ipynb               # EDA, imbalance, schema validation
│   ├── 02_classical_machine_learning.ipynb     # Classical models & Stratified CV
│   ├── 03_quantum_machine_learning.ipynb       # Quantum Kernel Classifier (QSVC)
│   ├── 04_quantum_optimization.ipynb           # QAOA vs Classical Brute Force
│   └── 05_quantum_simulation.ipynb             # 6-qubit circuit & Poisson-Binomial
│
├── src/                                        # Modular Clean Source Code
│   ├── utils.py                                # Seed, logger, paths
│   ├── data_preprocessing.py                   # Train-only preprocessing pipelines
│   ├── classical_models.py                     # Classical probabilistic models
│   ├── quantum_classifier.py                   # Quantum Kernel Classifier & metrics
│   ├── customer_prediction.py                  # Test scoring & top 10 ranking
│   ├── classical_optimizer.py                  # Exact brute force (210 combinations)
│   ├── quantum_optimizer.py                    # QAOA QUBO solver & bitstring decoding
│   ├── probability_calculation.py              # Poisson-Binomial DP & Monte Carlo
│   ├── quantum_simulation.py                   # 6-qubit RY circuit simulator
│   └── visualization.py                        # 18 FinTech publication charts
│
├── outputs/                                    # Official Generated Deliverables
│   ├── stage1_predictions.csv                  # 100 test customer probabilities & ranks
│   ├── stage2_optimization_results.csv         # Top 10 candidate optimization results
│   ├── stage3_quantum_simulation_results.csv   # 6-qubit simulation & error comparisons
│   ├── model_comparison.csv                    # 6-model cross-validation comparison
│   └── charts/                                 # 18 high-resolution PNG charts
│
├── reports/                                    # Documentation & Reports
│   ├── technical_report.md                     # Comprehensive 19-section technical report
│   └── executive_summary.pdf                   # Multi-page executive summary PDF
│
├── app.py                                      # 7-page interactive Streamlit dashboard
├── run_pipeline.py                             # Master entry-point script
├── requirements.txt                            # Package dependencies
└── README.md                                   # Project documentation
```

---

## 🔬 Mathematical Formulations

### 1. Stage 2 QUBO & Ising Hamiltonian
$$\max \sum_{i=0}^9 \left( p_i V_i - c_i \right) x_i \iff \min H(x)$$
$$H(x) = -\sum_{i=0}^9 v_i x_i + P_k \left( \sum_{i=0}^9 x_i - 6 \right)^2 + P_c \left[ \max\left(0, \sum c_i x_i - 25\right) \right]^2 + P_h \left[ \max\left(0, \sum h_i x_i - 22\right) \right]^2$$

### 2. Stage 3 Quantum State Preparation
For each customer $i \in \{0, \dots, 5\}$ with predicted probability $p_i$:
$$\theta_i = 2 \arcsin\left(\sqrt{p_i}\right)$$
$$|\psi_i\rangle = RY(\theta_i)|0\rangle = \cos(\theta_i/2)|0\rangle + \sin(\theta_i/2)|1\rangle = \sqrt{1 - p_i}|0\rangle + \sqrt{p_i}|1\rangle$$
$$P(\text{qubit}_i = 1) = \sin^2(\theta_i/2) = p_i$$

### 3. Exact Classical Poisson-Binomial Dynamic Programming
Let $dp[k]$ be the probability of exactly $k$ subscriptions among the first $j$ customers:
$$dp_{new}[k] = dp[k] \cdot (1 - p_j) + dp[k - 1] \cdot p_j$$
$$P(K \ge 3) = \sum_{k=3}^6 dp[k]$$

---

## 🏆 Hackathon Compliance Checklist

- [x] All 300 training records used appropriately without data leakage.
- [x] All 100 test customers scored with continuous probabilities.
- [x] Top 10 candidate pool ranked deterministically with alphanumeric tie-breaker.
- [x] Exactly 6 customers selected within contact budget $\le 25$ and capacity $\le 22$.
- [x] QAOA implemented and compared against exact classical brute force (210 combinations).
- [x] 6-qubit quantum circuit implemented with exact single-qubit $RY(\theta_i)$ rotations.
- [x] Campaign success condition ($P(K \ge 3)$) validated against Poisson-Binomial analytical DP and Monte Carlo.
- [x] All three official CSV results generated: `stage1_predictions.csv`, `stage2_optimization_results.csv`, `stage3_quantum_simulation_results.csv`.
- [x] 18 high-resolution charts generated in `outputs/charts/`.
- [x] Interactive Streamlit app with 7 pages and real data integration.
- [x] Multi-page Executive Summary PDF generated in `reports/executive_summary.pdf`.
- [x] Fully reproducible under fixed random seed 42.
